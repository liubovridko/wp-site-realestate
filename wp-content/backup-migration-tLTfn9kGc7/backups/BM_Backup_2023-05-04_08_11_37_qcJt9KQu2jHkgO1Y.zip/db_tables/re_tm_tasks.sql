/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `re_tm_tasks`; */
/* PRE_TABLE_NAME: `1683187898_re_tm_tasks`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1683187898_re_tm_tasks` ( `id` int(11) NOT NULL AUTO_INCREMENT, `user_id` bigint(20) NOT NULL, `type` varchar(300) NOT NULL, `class_identifier` varchar(300) DEFAULT '0', `attempts` int(11) DEFAULT 0, `description` varchar(300) DEFAULT NULL, `time_created` timestamp NOT NULL DEFAULT current_timestamp(), `last_locked_at` bigint(20) DEFAULT 0, `status` varchar(300) DEFAULT NULL, PRIMARY KEY (`id`), KEY `user_id` (`user_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
