/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `re_termmeta`; */
/* PRE_TABLE_NAME: `1683187898_re_termmeta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1683187898_re_termmeta` ( `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `term_id` bigint(20) unsigned NOT NULL DEFAULT 0, `meta_key` varchar(255) DEFAULT NULL, `meta_value` longtext DEFAULT NULL, PRIMARY KEY (`meta_id`), KEY `term_id` (`term_id`), KEY `meta_key` (`meta_key`(191))) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1683187898_re_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES (1,17,'image',''),(2,17,'_image','field_63fa1ff8ebc3b'),(3,32,'image',''),(4,32,'_image','field_63fa1ff8ebc3b'),(5,3,'image',''),(6,3,'_image','field_63fa1ff8ebc3b'),(7,4,'image',''),(8,4,'_image','field_63fa1ff8ebc3b'),(9,34,'image',''),(10,34,'_image','field_63fa1ff8ebc3b'),(11,36,'image',''),(12,36,'_image','field_63fa1ff8ebc3b'),(13,38,'image',''),(14,38,'_image','field_63fa1ff8ebc3b'),(15,40,'image',''),(16,40,'_image','field_63fa1ff8ebc3b'),(17,42,'image',''),(18,42,'_image','field_63fa1ff8ebc3b'),(19,44,'image',''),(20,44,'_image','field_63fa1ff8ebc3b');
