/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `re_termmeta`; */
/* PRE_TABLE_NAME: `1682672185_re_termmeta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1682672185_re_termmeta` ( `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `term_id` bigint(20) unsigned NOT NULL DEFAULT 0, `meta_key` varchar(255) DEFAULT NULL, `meta_value` longtext DEFAULT NULL, PRIMARY KEY (`meta_id`), KEY `term_id` (`term_id`), KEY `meta_key` (`meta_key`(191))) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1682672185_re_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES (1,17,'image',''),(2,17,'_image','field_63fa1ff8ebc3b');
