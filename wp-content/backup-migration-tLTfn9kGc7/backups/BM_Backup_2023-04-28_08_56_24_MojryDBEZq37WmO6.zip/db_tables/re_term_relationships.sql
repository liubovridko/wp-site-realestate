/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `re_term_relationships`; */
/* PRE_TABLE_NAME: `1682672185_re_term_relationships`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1682672185_re_term_relationships` ( `object_id` bigint(20) unsigned NOT NULL DEFAULT 0, `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0, `term_order` int(11) NOT NULL DEFAULT 0, PRIMARY KEY (`object_id`,`term_taxonomy_id`), KEY `term_taxonomy_id` (`term_taxonomy_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1682672185_re_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES (1,7,0),(1,8,0),(2,6,0),(2,15,0),(3,6,0),(3,7,0),(3,13,0),(4,7,0),(4,14,0),(5,2,0),(9,1,0),(9,6,0),(11,8,0),(11,10,0),(12,2,0),(13,2,0),(14,2,0),(15,2,0),(27,1,0),(27,3,0),(27,4,0),(27,6,0),(40,6,0),(41,6,0),(42,6,0),(43,6,0),(44,6,0),(46,6,0),(48,6,0),(64,9,0),(64,15,0),(65,2,0),(66,6,0),(66,16,0),(67,9,0),(67,16,0),(68,6,0),(69,6,0);
